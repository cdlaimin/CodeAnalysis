import{_ as e}from"./app.14bd3eec.js";const _={};function r(n,t){return null}var f=e(_,[["render",r],["__file","index.html.vue"]]);export{f as default};
