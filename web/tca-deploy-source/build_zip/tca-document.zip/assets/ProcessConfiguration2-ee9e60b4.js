const s="/document/assets/Nodemanagement-f5415093.png",o="/document/assets/ProcessConfiguration2-b0d699f7.png";export{s as _,o as a};
