var s="/document/assets/AddRule.868e55e0.png",e="/document/assets/AddRule2.84297356.png",a="/document/assets/AddRule3.c3402a44.png";export{s as _,e as a,a as b};
