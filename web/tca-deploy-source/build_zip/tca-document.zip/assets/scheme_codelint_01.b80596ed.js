var e="/document/assets/scheme_codelint_01.3a155b75.png";export{e as _};
