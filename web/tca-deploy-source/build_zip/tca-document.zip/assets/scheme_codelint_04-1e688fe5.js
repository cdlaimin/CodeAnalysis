const s="/document/assets/scheme_codelint_04-a63f9fcd.png";export{s as _};
