const s="/document/assets/manage_org_01-4220e65f.png",a="/document/assets/manage_org_02-d813adb5.png";export{s as _,a};
