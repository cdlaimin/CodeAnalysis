const s="/document/assets/start_scan_03-87d30568.png";export{s as _};
